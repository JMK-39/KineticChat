package dev.xyat.kineticchat;

import com.mojang.logging.LogUtils;
import dev.xyat.kineticchat.chat.command.ChatCommandExtension;
import dev.xyat.kineticchat.chat.config.ChatConfig;
import dev.xyat.kineticchat.chat.config.ChatConfigGui;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(KineticChat.MODID)
public final class KineticChat {
    public static final String MODID = "kineticchat";
    public static final Logger LOGGER = LogUtils.getLogger();

    public KineticChat(FMLJavaModLoadingContext context) {
        ChatConfig.load();
        ChatCommandExtension.install();
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ChatConfigGui::load);
    }
}
